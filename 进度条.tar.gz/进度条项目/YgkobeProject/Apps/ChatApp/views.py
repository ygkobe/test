# -*- coding:utf8 -8_


import warnings
# 抑制特定的警告
warnings.filterwarnings("ignore", message="pandas only supports SQLAlchemy connectable.*")


