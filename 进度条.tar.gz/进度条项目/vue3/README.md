```shell
npm install --legacy-peer-deps

npm run build --legacy-peer-deps

```


```shell
# 创建数据库
CREATE DATABASE chat CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```